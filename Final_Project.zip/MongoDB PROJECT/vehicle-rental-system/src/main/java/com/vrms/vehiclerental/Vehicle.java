package com.vrms.vehiclerental;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "vehicles")
public class Vehicle {

    @Id
    private String id;
    private String vehicleName;
    private String type;
    private boolean available;
    private double rentPerDay;

    public Vehicle() {
    }

    public Vehicle(String vehicleName, String type, boolean available) {
        this.vehicleName = vehicleName;
        this.type = type;
        this.available = available;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public double getRentPerDay() {
    return rentPerDay;
    }

    public void setRentPerDay(double rentPerDay) {
    this.rentPerDay = rentPerDay;
    }
}