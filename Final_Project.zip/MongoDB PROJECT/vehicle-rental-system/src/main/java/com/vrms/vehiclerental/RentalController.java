package com.vrms.vehiclerental;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/rentals")
public class RentalController {

    @Autowired
    private RentalRepository rentalRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    @PostMapping
    public Rental createRental(@RequestBody Rental rental) {

        Vehicle vehicle = vehicleRepository
                .findById(rental.getVehicleId())
                .orElse(null);

        if (vehicle == null) {
            throw new RuntimeException("Vehicle not found!");
        }

        if (!vehicle.isAvailable()) {
            throw new RuntimeException("Vehicle is already rented!");
        }

        LocalDate start = LocalDate.parse(rental.getStartDate());
LocalDate end = LocalDate.parse(rental.getEndDate());

long days = ChronoUnit.DAYS.between(start, end);

if(days <= 0){
    days = 1;
}

double totalCost = days * vehicle.getRentPerDay();

rental.setTotalCost(totalCost);

vehicle.setAvailable(false);
vehicleRepository.save(vehicle);

return rentalRepository.save(rental);
    }

    @GetMapping
    public List<Rental> getAllRentals() {
        return rentalRepository.findAll();
    }

    @DeleteMapping("/{id}")
    public String returnVehicle(@PathVariable String id) {

        Rental rental = rentalRepository.findById(id).orElse(null);

        if (rental == null) {
            return "Rental not found!";
        }

        Vehicle vehicle = vehicleRepository
                .findById(rental.getVehicleId())
                .orElse(null);

        if (vehicle != null) {
            vehicle.setAvailable(true);
            vehicleRepository.save(vehicle);
        }

        rentalRepository.deleteById(id);

        return "Vehicle returned successfully!";
    }
}