package com.vrms.vehiclerental;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/vehicles")
public class VehicleController {

    @Autowired
    private VehicleRepository repository;

    @PostMapping
    public Vehicle addVehicle(@RequestBody Vehicle vehicle) {
        return repository.save(vehicle);
    }

    @GetMapping
    public List<Vehicle> getAllVehicles() {
        return repository.findAll();
    }

@PutMapping("/{id}")
public Vehicle updateVehicle(@PathVariable String id,
                             @RequestBody Vehicle updatedVehicle) {

    Vehicle vehicle = repository.findById(id).orElse(null);

    if (vehicle != null) {
        vehicle.setVehicleName(updatedVehicle.getVehicleName());
        vehicle.setType(updatedVehicle.getType());
        vehicle.setAvailable(updatedVehicle.isAvailable());

        return repository.save(vehicle);
    }

    return null;
}

@DeleteMapping("/{id}")
public String deleteVehicle(@PathVariable String id) {

    repository.deleteById(id);

    return "Vehicle deleted successfully!";
}
@GetMapping("/{id}")
public Vehicle getVehicleById(@PathVariable String id) {
    return repository.findById(id).orElse(null);
}

@GetMapping("/available")
public List<Vehicle> getAvailableVehicles() {
    return repository.findByAvailable(true);
}
}